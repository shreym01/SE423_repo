to start streaming: python3 motive2.py
to add new robot:
1. train the new robot as a new rigid body in motive, record the streaming_id in the properties tab
2. modify the "address_id_dict" and add the new robot in the format of "streaming_id (in the motive software):192.168.1.xx (ip to stream)"
